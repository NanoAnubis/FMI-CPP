/**
*  
* Solution to course project # 7
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Lubomir Stoykov
* @idnumber 62569
* @compiler VC
*
* <header file with forward declaration of used functions>
*
*/

using namespace std;

void Check(const string& Regex, const string& Text, const int line_number);
bool CheckForMany(const string& array);