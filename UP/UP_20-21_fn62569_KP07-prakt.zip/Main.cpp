/**
*  
* Solution to course project # 7
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Lubomir Stoykov
* @idnumber 62569
* @compiler VC
*
* <main body of program code>
*
*/

#include<iostream>
#include<fstream>
#include<string>

#include "Check_functions.h"

using namespace std;

int main()
{
	fstream Input_file;
	string Line_for_checking;
	string Regex;
	string Input_file_name;

	int line_number = 1;

	cout << "Enter regex:" << endl;
	cin >> Regex;

	while (CheckForMany(Regex)) {
		cout << "Enter valid input!" << endl;
		cin >> Regex;
	}

	cout <<endl<< "Enter file:" << endl;
	//Input_file_name = "regex.txt";
	cin >> Input_file_name;
	cout << endl;

	Input_file.open(Input_file_name, fstream::in);

	if (!Input_file.is_open()) {
		cout << "Failed to open file!";
		return 1;
	}
	cout << "Lines that have the entered string:" << endl<<endl;

	while (getline(Input_file, Line_for_checking)) {
		Check(Regex, Line_for_checking, line_number);
		line_number++;
	}

	Input_file.close();

	return 0;
}