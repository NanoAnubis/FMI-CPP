/**
*  
* Solution to course project # 7
* Introduction to programming course
* Faculty of Mathematics and Informatics of Sofia University
* Winter semester 2020/2021
*
* @author Lubomir Stoykov
* @idnumber 62569
* @compiler VC
*
* <general functions used in main.cpp>
*
*/

#include<iostream>
#include<fstream>
#include<string>

using namespace std;

void Check(const string& Regex, const string& Text, const int line_number) {

	bool check = 0, symbol_Qmark = 0, repeat_Qmark = 0; // symbol_Qmark if '?' is in the regex or not
	size_t counter_reg = 0, counter_text = 0, revert = 0; // revert used for counting and going back in array if needed
	size_t sizeRegex = Regex.size();
	size_t sizeText = Text.size();

	while (counter_reg < sizeRegex && counter_text < sizeText) {
		if (Regex[counter_reg] == '.' && sizeRegex == 1) {
			check = 1;
			break;
		}
		if (sizeRegex > sizeText + 2) {
			break;
		}

		if (Regex[counter_reg] == '\\' && (counter_reg == 0 || Regex[counter_reg - 1] != '\\')) {
			counter_reg++;
		}

		if (Regex[counter_reg] == '^' && counter_reg == 0 && Regex[counter_reg - 1]!='\\') {
			if (Regex[counter_reg + 1] == '\0') {
				check = 1;
				break;
			}
			counter_reg++;
			sizeText = sizeRegex;
		}

		if (Regex[counter_reg + 1] == '*' && Regex[counter_reg] != '\\') {
			if (sizeRegex == 2) {
				check = 1;
				break;
			}
			else if (check == 1) {
				break;
			}
			else if (check == 0) {
				counter_text++;
			}
		}

		if (Regex[counter_reg + 1] == '+' && Regex[counter_reg] != '\\') {
			if (sizeRegex == 2 && Text[counter_text] == Regex[counter_reg]) {
				check = 1;
				break;
			}
			else if (sizeRegex == 2 && Text[counter_text] != Regex[counter_reg]) {
				counter_text++;
				continue;
			}
			else if (check == 1 && Text[counter_text] == Regex[counter_reg]) {
				break;
			}
			else if (check == 0) {
				counter_text++;
			}
		}

		if (Regex[counter_reg + 1] == '?' && repeat_Qmark == 0 && Regex[counter_reg] != '\\') {
			if (sizeRegex == 2) {
				check = 1;
				break;
			}
			else {
				symbol_Qmark = 1;
				counter_reg += 2;
				if (counter_reg >= sizeRegex) {
					break;
				}
			}
		}

		if (Regex[counter_reg] == '?' && repeat_Qmark == 1 && Regex[counter_reg - 1] != '\\') {
			if (sizeRegex == 2) {
				check = 1;
				break;
			}
			else {
				symbol_Qmark = 0;
				counter_reg += 1;
				if (counter_reg >= sizeRegex) {
					break;
				}
			}
		}

		if ((Regex[counter_reg] == Text[counter_text] || (Regex[counter_reg] == '.' && (counter_reg == 0 || Regex[counter_reg - 1] != '\\'))) && check == 1) {
			revert++;
			counter_reg++;
			counter_text++;
			if (counter_text >= sizeText && counter_reg < sizeRegex) {
				check = 0;
				if (symbol_Qmark == 1 && repeat_Qmark == 0) {
					counter_reg = 0;
					counter_text = 0;
					revert = 0;
					repeat_Qmark = 1;
					continue;
				}
				break;
			}
		}

		else if (check == 1) {
			counter_reg = 0;
			counter_text = counter_text - (revert - 1);
			revert = 0;
			check = 0;
		}

		if ((Regex[counter_reg] == Text[counter_text] || (Regex[counter_reg] == '.' && (counter_reg == 0 || Regex[counter_reg - 1] != '\\'))) && check == 0) {
			check = 1;
			revert++;
			counter_reg++;
			counter_text++;
		}

		else if (Regex[counter_reg] != Text[counter_text] && check == 0) {
			counter_text++;
		}

		if (counter_text >= sizeText && counter_reg < sizeRegex) {
			check = 0;
			if (symbol_Qmark == 1 && repeat_Qmark == 0) {
				counter_reg = 0;
				counter_text = 0;
				revert = 0;
				repeat_Qmark = 1;
				continue;
			}
			break;
		}

		if (check == 0 && symbol_Qmark == 1 && repeat_Qmark == 0 && (counter_reg >= sizeRegex || counter_text >= sizeText)) {
			counter_reg = 0;
			counter_text = 0;
			revert = 0;
			repeat_Qmark = 1;
			continue;
		}
	}

	if (check == 1) {
		cout << "Line " << line_number << ": ";
		cout << Text << endl << endl;
	}

	return;
}

bool CheckForMany(const string& array) {
	int number_of_specials = 0;
	int exclude = 0;
	int size = array.size();
	for (int i = 0; i < size; i++) {

		if (array[i] == '*' || array[i] == '+' || array[i] == '?') {
			number_of_specials++;
		}
		if (array[i] == '\\') {
			exclude++;
		}
		if (array[i] == '.' && array[i + 1] == '.' && (i==0 || array[i - 1] != '\\')) {
			return 1;
		}
		if (array[i] == '^' && i != 0 && array[i - 1] != '\\') {
			return 1;
		}
		if (array[0] == '*' || array[0] == '+' || array[0] == '?') {
			return 1;
		}
		if (array[i] == '\\' && ((array[i + 1] >= 'A' && array[i + 1] <= 'Z') || (array[i + 1] >= 'a' && array[i + 1] <= 'z') || (array[i+1]=='\0' && array[i-1]!='\\'))) {
			return 1;
		}
	}

	if (number_of_specials - exclude > 1) {
		return 1;
	}
	return 0;
}